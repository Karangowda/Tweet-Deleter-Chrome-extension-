# Tweet Eraser — Chrome Extension

Bulk delete all your tweets directly from X/Twitter, with no third-party services or API keys required.

---

## Installation

1. Open Chrome and go to `chrome://extensions/`
2. Enable **Developer Mode** (toggle in the top-right corner)
3. Click **"Load unpacked"**
4. Select the `tweet-deleter/` folder

The extension icon will appear in your Chrome toolbar.

---

## How to Use

1. Go to **x.com** and log into your account
2. Navigate to **your profile page** (e.g., `x.com/yourusername`)
3. Click the **Tweet Eraser** extension icon
4. Adjust the **delay** slider (slower = safer, avoids rate limits)
5. Click **"START DELETION"** and confirm
6. The extension scrolls your profile and deletes tweets one by one
7. Click **STOP** any time to pause

---

## How It Works

- Injects a content script into X/Twitter pages
- Finds tweet "More" (···) menus and clicks **Delete → Confirm**
- Also handles **Retweets** (via Undo Retweet)
- Scrolls automatically to load more tweets
- Tracks deleted/failed counts across sessions (stored locally)

---

## Tips

- Stay on your **profile page** (`/yourusername`) for best results
- Use a **1–2 second delay** to avoid being rate-limited by Twitter
- If tweets stop appearing, refresh the page and restart
- The extension works on both `x.com` and `twitter.com`

---

## Limitations

- Can only delete tweets that are **visible in the DOM** (i.e., loaded on screen)
- Twitter may rate-limit heavy deletion — if so, pause and try later
- Does not use the Twitter API — works entirely through the browser UI
- Pinned tweets or certain media tweets may occasionally require a manual retry

---

## Privacy

All data stays local. No servers, no API keys, no accounts needed.
