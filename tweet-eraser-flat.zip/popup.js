// popup.js — v2.0

const $ = id => document.getElementById(id);

// ── State ──────────────────────────────────────────────────────────────────────
let isRunning   = false;
let activeTabId = null;
let delay       = 1000;

// Session counters
let session = { tweets: 0, retweets: 0, replies: 0, failed: 0 };

// ── DOM refs ──────────────────────────────────────────────────────────────────
const statusDot    = $('statusDot');
const statusText   = $('statusText');
const mainUI       = $('mainUI');
const notTwitter   = $('notTwitter');
const btnStart     = $('btnStart');
const btnStop      = $('btnStop');
const btnConfirm   = $('btnConfirm');
const btnCancel    = $('btnCancel');
const overlay      = $('overlay');
const log          = $('log');
const delaySlider  = $('delaySlider');
const delayVal     = $('delayVal');
const noSel        = $('noSel');
const confirmSum   = $('confirmSummary');
const dateFrom     = $('dateFrom');
const dateTo       = $('dateTo');

// ── Init ──────────────────────────────────────────────────────────────────────
async function init() {
  // Load saved counters
  const saved = await chrome.storage.local.get(['allTime']);
  // (all-time totals stored separately, session starts at 0)

  // Set default dateTo to today
  dateTo.value = new Date().toISOString().split('T')[0];

  // Check tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const isTwitter = tab && /^https?:\/\/(twitter|x)\.com/.test(tab.url);

  if (!isTwitter) {
    setStatus('warn', 'NOT ON X/TWITTER');
    notTwitter.classList.add('visible');
    $('openTwitter').addEventListener('click', e => {
      e.preventDefault();
      chrome.tabs.create({ url: 'https://x.com' });
    });
    return;
  }

  activeTabId = tab.id;
  mainUI.style.display = 'block';

  try {
    const resp = await sendToContent({ action: 'getStatus' });
    if (resp && resp.running) {
      setRunningState(true);
    } else {
      setStatus('active', 'READY');
    }
  } catch {
    setStatus('active', 'READY');
  }
}

// ── Status ────────────────────────────────────────────────────────────────────
function setStatus(type, text) {
  statusDot.className = 'dot ' + ({ active:'active', running:'running', warn:'warn' }[type] || '');
  statusText.textContent = text;
}

// ── Live counter ──────────────────────────────────────────────────────────────
function bumpCounter(kind) {
  // kind: 'tweets' | 'retweets' | 'replies' | 'failed'
  session[kind]++;
  const elId = { tweets:'cntTweets', retweets:'cntRT', replies:'cntReplies', failed:'cntFailed' }[kind];
  const lcId = { tweets:'lcTweets',  retweets:'lcRT',  replies:'lcReplies',  failed:'lcFailed'  }[kind];
  const valEl = $(elId);
  const lcEl  = $(lcId);

  valEl.textContent = session[kind];

  // Pop animation
  valEl.classList.remove('bump');
  void valEl.offsetWidth; // reflow
  valEl.classList.add('bump');
  setTimeout(() => valEl.classList.remove('bump'), 200);

  // Light up underline
  lcEl.classList.add('lit');
  clearTimeout(lcEl._litTimer);
  lcEl._litTimer = setTimeout(() => lcEl.classList.remove('lit'), 1200);
}

// ── Logging ───────────────────────────────────────────────────────────────────
function addLog(msg, cls = '') {
  const entry = document.createElement('div');
  entry.className = 'log-entry ' + cls;
  const t = new Date().toLocaleTimeString('en', { hour12:false, hour:'2-digit', minute:'2-digit', second:'2-digit' });
  entry.textContent = `[${t}] ${msg}`;
  log.appendChild(entry);
  log.scrollTop = log.scrollHeight;
  while (log.children.length > 80) log.removeChild(log.firstChild);
}

// ── Running state ─────────────────────────────────────────────────────────────
function setRunningState(running) {
  isRunning = running;
  btnStart.disabled = running;
  btnStop.classList.toggle('visible', running);
  if (running) {
    setStatus('running', 'DELETING...');
  } else {
    setStatus('active', 'READY');
  }
}

// ── Messaging ─────────────────────────────────────────────────────────────────
function sendToContent(msg) {
  return chrome.tabs.sendMessage(activeTabId, msg);
}

// ── Inbound messages from content script ──────────────────────────────────────
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'deleted_tweet') {
    bumpCounter('tweets');
    addLog('Deleted tweet', 'tweet');
  } else if (msg.type === 'deleted_retweet') {
    bumpCounter('retweets');
    addLog('Undid retweet', 'rt');
  } else if (msg.type === 'deleted_reply') {
    bumpCounter('replies');
    addLog('Deleted reply', 'reply');
  } else if (msg.type === 'skipped') {
    bumpCounter('failed');
    addLog(`Skipped: ${msg.reason || ''}`, 'error');
  } else if (msg.type === 'log') {
    addLog(msg.text, msg.level || '');
  } else if (msg.type === 'done') {
    setRunningState(false);
    const total = session.tweets + session.retweets + session.replies;
    addLog(`Session complete — ${total} removed (${session.tweets}T ${session.retweets}RT ${session.replies}R), ${session.failed} skipped.`, 'info');
  } else if (msg.type === 'error') {
    setRunningState(false);
    addLog(`Error: ${msg.text}`, 'error');
  }
});

// ── Date presets ──────────────────────────────────────────────────────────────
document.querySelectorAll('.preset-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.preset-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    const preset = btn.dataset.preset;
    const today = new Date();
    const toStr = d => d.toISOString().split('T')[0];

    if (preset === 'all') {
      dateFrom.value = '';
      dateTo.value   = toStr(today);
    } else {
      const days = { '7d':7, '30d':30, '90d':90, '1y':365 }[preset];
      const from = new Date(today);
      from.setDate(from.getDate() - days);
      dateFrom.value = toStr(from);
      dateTo.value   = toStr(today);
    }
  });
});

// Clear preset highlight when user manually edits dates
[dateFrom, dateTo].forEach(el => {
  el.addEventListener('change', () => {
    document.querySelectorAll('.preset-btn').forEach(b => b.classList.remove('active'));
  });
});

// ── Delay slider ──────────────────────────────────────────────────────────────
delaySlider.addEventListener('input', () => {
  delay = parseInt(delaySlider.value);
  delayVal.textContent = (delay / 1000).toFixed(1) + 's';
});

// ── Log clear ────────────────────────────────────────────────────────────────
$('btnClearLog').addEventListener('click', () => {
  log.innerHTML = '';
  addLog('Log cleared.', '');
});

// ── Confirm summary builder ───────────────────────────────────────────────────
function buildConfirmSummary() {
  const types = [];
  if ($('inclTweets').checked)   types.push('<b style="color:#e8392b">Tweets</b>');
  if ($('inclRetweets').checked) types.push('<b style="color:#22c55e">Retweets</b>');
  if ($('inclReplies').checked)  types.push('<b style="color:#3b8ff3">Replies</b>');

  const fromVal = dateFrom.value;
  const toVal   = dateTo.value;
  let dateStr = 'All time';
  if (fromVal && toVal) dateStr = `${fromVal} → ${toVal}`;
  else if (fromVal)     dateStr = `From ${fromVal}`;
  else if (toVal)       dateStr = `Up to ${toVal}`;

  confirmSum.innerHTML =
    `Types: ${types.join(', ')}<br>` +
    `Date range: <b>${dateStr}</b><br>` +
    `Delay: <b>${(delay/1000).toFixed(1)}s</b> between actions`;
}

// ── Start button ──────────────────────────────────────────────────────────────
btnStart.addEventListener('click', () => {
  const anySelected = $('inclTweets').checked || $('inclRetweets').checked || $('inclReplies').checked;
  if (!anySelected) {
    noSel.classList.add('visible');
    return;
  }
  noSel.classList.remove('visible');
  buildConfirmSummary();
  overlay.classList.add('visible');
});

btnCancel.addEventListener('click', () => overlay.classList.remove('visible'));

btnConfirm.addEventListener('click', async () => {
  overlay.classList.remove('visible');

  // Reset session counters
  session = { tweets: 0, retweets: 0, replies: 0, failed: 0 };
  ['cntTweets','cntRT','cntReplies','cntFailed'].forEach(id => $(id).textContent = '0');

  setRunningState(true);
  addLog('Starting…', 'info');

  const config = {
    action:      'start',
    delay,
    inclTweets:   $('inclTweets').checked,
    inclRetweets: $('inclRetweets').checked,
    inclReplies:  $('inclReplies').checked,
    dateFrom:     dateFrom.value || null,
    dateTo:       dateTo.value   || null,
  };

  try {
    await sendToContent(config);
  } catch (e) {
    addLog('Could not reach page script. Reload X/Twitter and try again.', 'error');
    setRunningState(false);
  }
});

btnStop.addEventListener('click', async () => {
  addLog('Stopping…', 'info');
  try { await sendToContent({ action: 'stop' }); } catch {}
  setRunningState(false);
});

// ── Boot ──────────────────────────────────────────────────────────────────────
init();
