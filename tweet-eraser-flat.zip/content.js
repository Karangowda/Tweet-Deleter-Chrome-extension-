// content.js — v2.0
// Injected into X/Twitter pages

(function () {
  if (window.__tweetEraserV2) return;
  window.__tweetEraserV2 = true;

  let running = false;
  let config  = {};

  // ── Helpers ────────────────────────────────────────────────────────────────

  const sleep = ms => new Promise(r => setTimeout(r, ms));

  function send(type, extra = {}) {
    try { chrome.runtime.sendMessage({ type, ...extra }); } catch {}
  }

  function log(text, level = '') {
    send('log', { text, level });
  }

  // ── Tweet classification ───────────────────────────────────────────────────
  // Returns 'tweet' | 'retweet' | 'reply' | null

  function classifyArticle(article) {
    // Retweet/Repost: has a "Retweeted" or "Reposted" social-context line
    const socialCtx = article.querySelector('[data-testid="socialContext"]');
    if (socialCtx && /retweeted|reposted/i.test(socialCtx.textContent)) return 'retweet';

    // Reply: the tweet has an "in reply to" header OR is part of a conversation thread
    // and isn't the root post. Check for reply indicator.
    const replyingTo = article.querySelector('[data-testid="reply"]');
    // Also check for "Replying to @..." text pattern
    const allSpans = article.querySelectorAll('span');
    for (const span of allSpans) {
      if (/replying to/i.test(span.textContent)) return 'reply';
    }

    // Another reliable signal: look for the "in reply to" div above the tweet text
    // Twitter wraps reply targets in a specific structure
    const tweetText = article.querySelector('[data-testid="tweetText"]');
    if (tweetText) {
      // Check if article has ancestor conversation thread context
      const prevSibling = article.previousElementSibling;
      if (prevSibling && prevSibling.querySelector('[data-testid="tweet"]')) return 'reply';
    }

    return 'tweet';
  }

  // ── Date extraction ───────────────────────────────────────────────────────

  function getTweetDate(article) {
    const timeEl = article.querySelector('time');
    if (!timeEl) return null;
    const dt = timeEl.getAttribute('datetime');
    if (!dt) return null;
    return new Date(dt);
  }

  function isInDateRange(date) {
    if (!date) return true; // Can't determine, include it
    const { dateFrom, dateTo } = config;
    if (dateFrom) {
      const from = new Date(dateFrom + 'T00:00:00');
      if (date < from) return false;
    }
    if (dateTo) {
      const to = new Date(dateTo + 'T23:59:59');
      if (date > to) return false;
    }
    return true;
  }

  // Is the tweet too old (before our dateFrom range)?
  function isTooOld(date) {
    if (!date || !config.dateFrom) return false;
    const from = new Date(config.dateFrom + 'T00:00:00');
    return date < from;
  }

  // ── DOM interaction ───────────────────────────────────────────────────────

  function clickMenuItemByText(...texts) {
    const items = document.querySelectorAll('[role="menuitem"]');
    for (const item of items) {
      const txt = item.textContent.trim().toLowerCase();
      for (const t of texts) {
        if (txt.includes(t.toLowerCase())) {
          item.click();
          return true;
        }
      }
    }
    return false;
  }

  function pressEscape() {
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  }

  // ── Single item processor ─────────────────────────────────────────────────
  // Returns: 'deleted_tweet' | 'deleted_retweet' | 'deleted_reply' | 'skipped' | 'no_more'

  async function processFirstItem() {
    const articles = document.querySelectorAll('article[data-testid="tweet"]');
    if (!articles.length) return 'no_more';

    // Find first processable article
    for (const article of articles) {
      if (article.dataset.erasing) continue; // already being processed

      const kind = classifyArticle(article);
      const date = getTweetDate(article);

      // Date range check
      if (!isInDateRange(date)) {
        // Mark and skip — but note if it's too old to stop scrolling
        article.dataset.erasing = 'skip';
        if (isTooOld(date)) {
          return 'too_old';
        }
        continue;
      }

      // Content type filter
      const shouldProcess =
        (kind === 'tweet'   && config.inclTweets)   ||
        (kind === 'retweet' && config.inclRetweets) ||
        (kind === 'reply'   && config.inclReplies);

      if (!shouldProcess) {
        article.dataset.erasing = 'skip';
        send('skipped', { reason: `${kind} excluded by filter` });
        continue;
      }

      // Mark as being processed
      article.dataset.erasing = 'processing';

      // ── Retweet/Repost: undo via retweet/repost button ──
      if (kind === 'retweet') {
        // X uses data-testid="unretweet" or "retweet" (when active) depending on version
        const rtBtn = article.querySelector('[data-testid="unretweet"], [data-testid="retweet"][aria-label*="Reposted"], [data-testid="retweet"][aria-label*="Retweeted"]');
        if (rtBtn) {
          rtBtn.click();
          await sleep(700);
          // Confirm dialog — X uses different testids for retweet vs repost
          const confirmBtn = document.querySelector('[data-testid="unretweetConfirm"], [data-testid="retweetConfirm"]');
          if (confirmBtn) {
            confirmBtn.click();
          } else {
            clickMenuItemByText('undo retweet', 'undo repost', 'unretweet', 'unrepost');
          }
          await sleep(config.delay);
          return 'deleted_retweet';
        }
        // Fallback: use caret menu
      }

      // ── Tweet / Reply: use caret (···) menu ──
      const caret = article.querySelector('[data-testid="caret"]');
      if (!caret) {
        article.dataset.erasing = 'skip';
        send('skipped', { reason: 'No menu button found' });
        continue;
      }

      caret.click();
      await sleep(650);

      // Click Delete in dropdown
      const deleted = clickMenuItemByText('delete', 'delete tweet', 'delete post');
      if (!deleted) {
        // For retweets/reposts that fell through to the caret menu
        const undone = clickMenuItemByText('undo retweet', 'undo repost', 'unretweet', 'unrepost');
        if (undone) {
          await sleep(config.delay);
          return 'deleted_retweet';
        }
        pressEscape();
        await sleep(400);
        article.dataset.erasing = 'skip';
        send('skipped', { reason: 'No delete option in menu' });
        continue;
      }

      await sleep(700);

      // Confirm deletion
      const confirmed =
        (() => { const b = document.querySelector('[data-testid="confirmationSheetConfirm"]'); if(b){b.click();return true;} return false; })() ||
        clickMenuItemByText('delete', 'confirm', 'yes');

      if (!confirmed) {
        pressEscape();
        await sleep(400);
        article.dataset.erasing = 'skip';
        send('skipped', { reason: 'Confirmation dialog not found' });
        continue;
      }

      await sleep(config.delay);

      if (kind === 'reply') return 'deleted_reply';
      return 'deleted_tweet';
    }

    return 'no_more';
  }

  // ── Main loop ─────────────────────────────────────────────────────────────

  async function startDeletion() {
    running = true;
    log('Scanning for content…', 'info');

    let emptyStreak = 0;
    let tooOldStreak = 0;

    while (running) {
      try {
        const result = await processFirstItem();

        if (result === 'deleted_tweet')    { send('deleted_tweet');    emptyStreak = 0; tooOldStreak = 0; }
        else if (result === 'deleted_retweet') { send('deleted_retweet'); emptyStreak = 0; tooOldStreak = 0; }
        else if (result === 'deleted_reply')   { send('deleted_reply');   emptyStreak = 0; tooOldStreak = 0; }
        else if (result === 'too_old') {
          tooOldStreak++;
          if (tooOldStreak >= 3) {
            log('All remaining tweets are older than the date filter. Stopping.', 'info');
            break;
          }
          window.scrollBy(0, 400);
          await sleep(1200);
        } else {
          // no_more: scroll and try again
          emptyStreak++;
          if (emptyStreak >= 5) {
            log('No more matching items found.', 'info');
            break;
          }
          window.scrollBy(0, 500);
          await sleep(1400);
        }
      } catch (err) {
        log(`Error: ${err.message}`, 'error');
        await sleep(1000);
      }
    }

    running = false;
    send('done');
  }

  // ── Message listener ──────────────────────────────────────────────────────

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'getStatus') {
      sendResponse({ running });
      return true;
    }

    if (msg.action === 'start' && !running) {
      config = {
        delay:        msg.delay        || 1000,
        inclTweets:   msg.inclTweets   !== false,
        inclRetweets: !!msg.inclRetweets,
        inclReplies:  !!msg.inclReplies,
        dateFrom:     msg.dateFrom     || null,
        dateTo:       msg.dateTo       || null,
      };
      startDeletion();
      sendResponse({ ok: true });
      return true;
    }

    if (msg.action === 'stop') {
      running = false;
      sendResponse({ ok: true });
      return true;
    }
  });

})();
